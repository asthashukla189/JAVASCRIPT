const prompt= require('prompt-sync')();

let a =prompt("Enter your age")
console.log(a); 
