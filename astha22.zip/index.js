const prompt= require('prompt-sync')();
let x= (Math.floor(Math.random()*10))
console.log(x)
let y;
do { y= prompt("Enter a number bw 0 to 10")
y= Number.parseInt(y)
if(x==y)
  console.log("your guess is correct")
  
if(x>y)
  console.log("your guess is less than the number")
  
 if(x<y)
  console.log("your guess is greater than the number")

   }
  while(x!=y)
