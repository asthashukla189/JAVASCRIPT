
  let user  =prompt("enter any one of the following: s, w, g")
  let cpuI = Math.floor(Math.random()*3)
  let cpu = ["s", "w", "g"][cpuI]
  const match =(user,cpu)=>{
    if(user === cpu){
      return 0
    }
    else if(user === "s" && cpu === "w"){
      return "user"
    }
    else if(user === "s" && cpu === "g"){
      return "cpu"
    }
    else if(user === "w" && cpu === "s"){
      return "cpu"}
      
    else if(user === "w" && cpu === "g"){
      return "user"}
      
    else if (user === "g" && cpu === "s"){
      return "user"}
    else if(user === "g" && cpu === "w"){
      return "cpu"}
  
  }
let result= match(user,cpu)
window.document.write( "user opted for ", user," but the computer chose ",cpu,"  hence the winner is  " + result)  

  
